import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Table, Button } from 'react-bootstrap';
import axios from 'axios';
import './styles.css';

function App() {
    const dispatch = useDispatch();
    const { users } = useSelector(state => state.users);
    const [newUser, setNewUser] = useState({ name: '', email: '', phone: '', address: { city: '', zipcode: '' } });
    const [editMode, setEditMode] = useState(false);
    const [editUserDetails, setEditUserDetails] = useState(null);

    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const response = await axios.get('https://jsonplaceholder.typicode.com/users');
                dispatch({ type: 'SET_USERS', payload: response.data });
            } catch (error) {
                console.error('Error fetching users', error);
            }
        };
        fetchUsers();
    }, [dispatch]);

    const check = Object.values(newUser).filter((item) => item !== '').length > 2

    const handleAddUser = () => {
        if (check && newUser.address.city !== '' && newUser.address.zipcode !== '') {
            dispatch({ type: 'ADD_USER', payload: { ...newUser, id: Date.now() } });
            setNewUser({ name: '', email: '', phone: '', address: { city: '', zipcode: '' } });
        }
        else {
            alert("Please Fill the Form ");
        }

    };

    const handleEditUser = (user) => {
        setEditMode(true);
        setEditUserDetails(user);
    };

    const handleUpdateUser = () => {
        dispatch({ type: 'EDIT_USER', payload: editUserDetails });
        setEditMode(false);
        setEditUserDetails(null);
    };

    const handleDeleteUser = (id) => {
        dispatch({ type: 'DELETE_USER', payload: id });
    };

    return (
        <div className="container">

            <h2>User Management</h2>
            <div className="table">
                <Table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>City & Zip Code</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {users.map(user => (
                            <tr key={user.id}>
                                <td>{user.id}</td>
                                <td>{user.name}</td>
                                <td>{user.email}</td>
                                <td>{user.phone}</td>
                                <td>{`${user.address.city}, ${user.address.zipcode}`}</td>
                                <td>
                                    <Button className="Edit-btn" onClick={() => handleEditUser(user)}>Edit</Button>{' '}
                                    <Button className="Delete-btn" onClick={() => handleDeleteUser(user.id)}>Delete</Button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </Table>
            </div>
            <h2>{editMode ? 'Edit User' : 'Add New User'}</h2>


            <div className='second-container'>


                <div className='first-box'>
                    <div>
                        <label style={{ marginRight: 10 }}>Name</label>
                        <input
                            className='custom-input'
                            type="text"
                            value={editMode ? editUserDetails?.name : newUser.name}
                            onChange={(e) =>
                                editMode
                                    ? setEditUserDetails({ ...editUserDetails, name: e.target.value })
                                    : setNewUser({ ...newUser, name: e.target.value })
                            }
                        />
                    </div>

                    <div>
                        <label style={{ marginRight: 10 }}>Email</label>
                        <input
                            className='custom-input'
                            type="email"
                            value={editMode ? editUserDetails?.email : newUser.email}
                            onChange={(e) =>
                                editMode
                                    ? setEditUserDetails({ ...editUserDetails, email: e.target.value })
                                    : setNewUser({ ...newUser, email: e.target.value })
                            }
                        />
                    </div>
                </div>

                <div className='second-box'>
                    <div>
                        <label style={{ marginRight: 10 }}>Phone</label>
                        <input
                            className='custom-input'
                            type="text"
                            value={editMode ? editUserDetails?.phone : newUser.phone}
                            onChange={(e) =>
                                editMode
                                    ? setEditUserDetails({ ...editUserDetails, phone: e.target.value })
                                    : setNewUser({ ...newUser, phone: e.target.value })
                            }
                        />
                    </div>
                    <div>
                        <label style={{ marginRight: 10 }}>City</label>
                        <input
                            className='custom-input'
                            type="text"
                            value={editMode ? editUserDetails?.address.city : newUser.address.city}
                            onChange={(e) =>
                                editMode
                                    ? setEditUserDetails({ ...editUserDetails, address: { ...editUserDetails.address, city: e.target.value } })
                                    : setNewUser({ ...newUser, address: { ...newUser.address, city: e.target.value } })
                            }
                        />
                    </div>
                </div>
                <div className='third-box'>
                    <div>
                        <label style={{ marginRight: 10 }}>Zip Code</label>
                        <input
                            className='custom-input'
                            type="text"
                            value={editMode ? editUserDetails?.address.zipcode : newUser.address.zipcode}
                            onChange={(e) =>
                                editMode
                                    ? setEditUserDetails({ ...editUserDetails, address: { ...editUserDetails.address, zipcode: e.target.value } })
                                    : setNewUser({ ...newUser, address: { ...newUser.address, zipcode: e.target.value } })
                            }
                        />
                    </div>
                    <div>
                        <Button className="add-update-btn" onClick={editMode ? handleUpdateUser : handleAddUser}>
                            {editMode ? 'Update User' : 'Add User'}
                        </Button>
                    </div>

                </div>

            </div>
        </div>
    );
}

export default App;
